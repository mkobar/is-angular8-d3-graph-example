import { Node, Link } from './';

//export interface MapTree {
export class MapTree {
  nodes: Node[] = [];
  links: Link[] = [];
}

